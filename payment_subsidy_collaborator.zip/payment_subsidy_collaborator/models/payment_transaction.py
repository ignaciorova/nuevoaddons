# -*- coding: utf-8 -*-
import logging
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    # Extra fields for subsidy payments
    subsidy_reference = fields.Char(
        string='Referencia de Subsidio',
        help='Referencia interna del pago de subsidio.',
    )
    subsidy_confirmed_by = fields.Many2one(
        'res.users',
        string='Confirmado por',
        readonly=True,
    )
    subsidy_confirmation_date = fields.Datetime(
        string='Fecha de Confirmación',
        readonly=True,
    )
    is_subsidy_payment = fields.Boolean(
        string='Es Pago de Subsidio',
        compute='_compute_is_subsidy_payment',
        store=True,
    )

    @api.depends('provider_code')
    def _compute_is_subsidy_payment(self):
        for tx in self:
            tx.is_subsidy_payment = tx.provider_code == 'subsidy_collaborator'

    # ------------------------------------------------------------------
    # Override: get_specific_rendering_values (used by website checkout)
    # ------------------------------------------------------------------
    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'subsidy_collaborator':
            return res

        # Generate a unique subsidy reference
        self.subsidy_reference = self.env['ir.sequence'].next_by_code(
            'payment.subsidy.sequence'
        ) or self.reference

        return {
            'subsidy_reference': self.subsidy_reference,
            'partner_name': self.partner_name,
            'amount': self.amount,
            'currency': self.currency_id.name,
        }

    # ------------------------------------------------------------------
    # Override: process notification data (auto-confirm)
    # ------------------------------------------------------------------
    def _process_notification_data(self, notification_data):
        super()._process_notification_data(notification_data)
        if self.provider_code != 'subsidy_collaborator':
            return

        # Auto confirm the transaction
        self._set_done()
        _logger.info(
            'Subsidy payment transaction %s auto-confirmed.', self.reference
        )

    # ------------------------------------------------------------------
    # Called when payment is manually validated from backend or website
    # ------------------------------------------------------------------
    def action_confirm_subsidy_payment(self):
        """
        Confirms the subsidy payment, sets it as done and sends notifications.
        Called from backend button or website controller.
        """
        for tx in self:
            if tx.provider_code != 'subsidy_collaborator':
                raise ValidationError(
                    _('Este método solo aplica para pagos de subsidio.')
                )
            if tx.state == 'done':
                continue

            # Mark as done
            tx._set_done()
            tx.subsidy_confirmed_by = self.env.user
            tx.subsidy_confirmation_date = fields.Datetime.now()

            # Confirm related sale orders
            for sale_order in tx.sale_order_ids:
                if sale_order.state in ('draft', 'sent'):
                    sale_order.action_confirm()

            # Send notifications
            tx._send_subsidy_notifications()

            _logger.info(
                'Subsidy payment %s confirmed by user %s.',
                tx.reference,
                self.env.user.name,
            )

    def _send_subsidy_notifications(self):
        """
        Sends email notifications to customer and admin after confirming
        a subsidy payment.
        """
        self.ensure_one()
        provider = self.provider_id

        # 1. Send via mail template if configured
        if provider.subsidy_notification_template_id:
            provider.subsidy_notification_template_id.send_mail(
                self.id, force_send=True
            )
        else:
            # Fallback: send a simple notification to the customer
            if self.partner_email:
                self.env['mail.mail'].sudo().create({
                    'subject': _('Confirmación de Pago de Subsidio - %s') % self.reference,
                    'email_to': self.partner_email,
                    'body_html': self._get_subsidy_customer_email_body(),
                    'auto_delete': True,
                }).send()

        # 2. Send admin notification
        if provider.subsidy_admin_email:
            self.env['mail.mail'].sudo().create({
                'subject': _('[Subsidio] Pago Confirmado - %s') % self.reference,
                'email_to': provider.subsidy_admin_email,
                'body_html': self._get_subsidy_admin_email_body(),
                'auto_delete': True,
            }).send()

        # 3. Post chatter message
        self.message_post(
            body=_('✅ Pago de subsidio confirmado. Notificaciones enviadas al cliente y administrador.'),
            message_type='comment',
            subtype_xmlid='mail.mt_note',
        )

    def _get_subsidy_customer_email_body(self):
        return """
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #2c7be5;">✅ Pago de Subsidio Confirmado</h2>
            <p>Estimado/a <strong>{partner_name}</strong>,</p>
            <p>Nos complace informarle que su pago de subsidio ha sido confirmado exitosamente.</p>
            <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
                <tr style="background:#f0f4ff;">
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Referencia</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{reference}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Monto</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{amount} {currency}</td>
                </tr>
                <tr style="background:#f0f4ff;">
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Fecha</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{date}</td>
                </tr>
            </table>
            <p>Gracias por su preferencia.</p>
        </div>
        """.format(
            partner_name=self.partner_name or '',
            reference=self.reference or '',
            amount=self.amount,
            currency=self.currency_id.name or '',
            date=fields.Datetime.now().strftime('%d/%m/%Y %H:%M'),
        )

    def _get_subsidy_admin_email_body(self):
        return """
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #28a745;">Nuevo Pago de Subsidio Confirmado</h2>
            <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
                <tr style="background:#f8f9fa;">
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Referencia</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{reference}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Cliente</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{partner}</td>
                </tr>
                <tr style="background:#f8f9fa;">
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Email</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{email}</td>
                </tr>
                <tr>
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Monto</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{amount} {currency}</td>
                </tr>
                <tr style="background:#f8f9fa;">
                    <td style="padding:8px; border:1px solid #ddd;"><strong>Confirmado por</strong></td>
                    <td style="padding:8px; border:1px solid #ddd;">{confirmed_by}</td>
                </tr>
            </table>
        </div>
        """.format(
            reference=self.reference or '',
            partner=self.partner_name or '',
            email=self.partner_email or '',
            amount=self.amount,
            currency=self.currency_id.name or '',
            confirmed_by=self.subsidy_confirmed_by.name if self.subsidy_confirmed_by else 'Sistema',
        )
