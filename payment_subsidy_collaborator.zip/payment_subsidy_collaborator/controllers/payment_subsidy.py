# -*- coding: utf-8 -*-
import logging
import pprint

from odoo import http, _
from odoo.http import request
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class PaymentSubsidyController(http.Controller):

    _return_url = '/payment/subsidy/return'
    _confirm_url = '/payment/subsidy/confirm'

    @http.route(
        _return_url,
        type='http',
        auth='public',
        methods=['GET', 'POST'],
        csrf=False,
        save_session=False,
    )
    def subsidy_return(self, **data):
        """
        Landing page after submitting the subsidy payment form on website.
        Auto-confirms the transaction.
        """
        _logger.info(
            'Subsidy payment return with data:\n%s', pprint.pformat(data)
        )
        try:
            tx_sudo = request.env['payment.transaction'].sudo().search([
                ('reference', '=', data.get('reference')),
                ('provider_code', '=', 'subsidy_collaborator'),
            ], limit=1)

            if tx_sudo:
                tx_sudo._process_notification_data(data)
        except ValidationError as e:
            _logger.error('Error processing subsidy payment: %s', str(e))

        return request.redirect('/payment/status')

    @http.route(
        '/payment/subsidy/validate/<int:tx_id>',
        type='json',
        auth='user',
        methods=['POST'],
    )
    def validate_subsidy_payment(self, tx_id, **kwargs):
        """
        Backend endpoint to manually confirm a subsidy payment.
        """
        tx_sudo = request.env['payment.transaction'].sudo().browse(tx_id)
        if not tx_sudo.exists():
            return {'success': False, 'error': _('Transacción no encontrada.')}

        try:
            tx_sudo.action_confirm_subsidy_payment()
            return {
                'success': True,
                'message': _('Pago confirmado y notificaciones enviadas.'),
            }
        except ValidationError as e:
            return {'success': False, 'error': str(e)}

    @http.route(
        '/payment/subsidy/pending',
        type='http',
        auth='public',
        website=True,
    )
    def subsidy_pending(self, **kwargs):
        """
        Page shown after a subsidy payment is submitted and pending review.
        """
        return request.render(
            'payment_subsidy_collaborator.subsidy_payment_pending_page',
            {}
        )
