{
    'name': 'XLabs Website Snippets',
    'version': '18.0.2.0.0',
    'summary': 'Snippets personalizados XLabs: carrusel estilo Metrohm y marquee de texto infinito',
    'author': 'XLabs Soluciones Integrales',
    'category': 'Website',
    'depends': ['website'],
    'data': [
        'views/snippets.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'xlabs_carousel_snippet/static/src/scss/s_xlabs_carousel.scss',
            'xlabs_carousel_snippet/static/src/scss/s_xlabs_marquee.scss',
            'xlabs_carousel_snippet/static/src/js/s_xlabs_carousel.js',
        ],
        'website.assets_wysiwyg': [
            'xlabs_carousel_snippet/static/src/snippets/s_xlabs_carousel/options.js',
            'xlabs_carousel_snippet/static/src/snippets/s_xlabs_marquee/options.js',
        ],
    },
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
