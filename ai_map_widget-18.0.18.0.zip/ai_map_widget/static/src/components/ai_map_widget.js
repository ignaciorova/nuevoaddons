/** @odoo-module **/

import { registry } from "@web/core/registry";
import { standardFieldProps } from "@web/views/fields/standard_field_props";
import { Component, useRef, onWillStart, onMounted, useState, xml } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { Dialog } from "@web/core/dialog/dialog";
import { loadJS, loadCSS } from "@web/core/assets";

class MapPopup extends Component {
    static template = "ai_map_widget.MapPopup";
    static components = { Dialog };

    static props = {
        close: Function,
        onSelect: Function,
    };

    setup() {
        this.mapContainerRef = useRef("mapContainer");
        this.mapInstance = null;
        this.marker = null;

        onMounted(() => {
            console.log("MapPopup Mounted -> Starting Map Init");
            this.initMapLogic();
        });
    }

    async initMapLogic() {
        // Delay 200ms to ensure that Modal take size
        await new Promise(resolve => setTimeout(resolve, 200));

        if (!this.mapContainerRef.el) {
            console.error("Map Container Element NOT FOUND!");
            return;
        }

        console.log("Initializing Leaflet Map...");

        // Default coordinates
        const defaultLat = 24.7136;
        const defaultLng = 46.6753;

        try {
            // 1. Create Map
            this.mapInstance = L.map(this.mapContainerRef.el).setView([defaultLat, defaultLng], 13);


            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: '© OpenStreetMap',
                maxZoom: 19,
            }).addTo(this.mapInstance);

            //  Marker
            this.marker = L.marker([defaultLat, defaultLng]).addTo(this.mapInstance);

            // Force Resize
            this.mapInstance.invalidateSize();
            console.log("Map Initialized Successfully");

            // Geolocation
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        console.log("Geolocation Found", position.coords);
                        this.updateMapPosition(position.coords.latitude, position.coords.longitude);
                    },
                    (err) => console.log("Geolocation Error", err)
                );
            }

            // Click Event
            this.mapInstance.on("click", (e) => {
                const { lat, lng } = e.latlng;
                this.updateMapPosition(lat, lng);
                this.props.onSelect(lat, lng);
                this.props.close();
            });

        } catch (error) {
            console.error("Error creating map:", error);
        }
    }

    updateMapPosition(lat, lng) {
        if (!this.mapInstance) return;
        this.mapInstance.setView([lat, lng], 13);
        if (this.marker) {
            this.marker.setLatLng([lat, lng]);
        }
        this.mapInstance.invalidateSize();
    }
}

export class DtcMapWidget extends Component {
    static template = "ai_map_widget.Field";
    static props = {
        ...standardFieldProps,
    };

    setup() {
        this.dialogService = useService("dialog");
        this.state = useState({ isLeafletLoaded: false });

        onWillStart(async () => {
            console.log("DtcMapWidget: Loading Leaflet Assets...");
            try {
                if (typeof L === "undefined") {
                    await Promise.all([
                        loadJS("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"),
                        loadCSS("https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"),
                    ]);
                }
                this.state.isLeafletLoaded = true;
                console.log("DtcMapWidget: Leaflet Loaded!");
            } catch (e) {
                console.error("Failed to load Leaflet", e);
                this.state.isLeafletLoaded = true;
            }
        });
    }

    openMap() {
        console.log("Button Clicked! Leaflet Loaded Status:", this.state.isLeafletLoaded);

        if (!this.state.isLeafletLoaded) {
            alert("Loading map libraries... please try again in a second.");
            return;
        }

        this.dialogService.add(MapPopup, {
            onSelect: (lat, lng) => {
                console.log("Location Selected:", lat, lng);
                const googleMapsLink = `http://maps.google.com/?q=${lat},${lng}`;
                this.props.record.update({ [this.props.name]: googleMapsLink });
            },
        });
    }
}

export const MapWidget = {
    component: DtcMapWidget,
    displayName: "Map Widget",
    supportedTypes: ["char"],
};

registry.category("fields").add("map_widget", MapWidget);