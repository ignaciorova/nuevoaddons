# -*- coding: utf-8 -*-
{
    'name': "Map Widget (Geolocation & Google Maps)",

    'summary': """
        Select locations easily on a map inside any form. 
        Auto-detects user location and saves as a Google Maps Link. 
        No API Key required (OpenStreetMap).
    """,

    'description': """
DTC Map Widget for Odoo 18
==========================

This module provides a modern, responsive Map Widget for Char fields in Odoo.
It allows users to pick a location visually and saves the result as a precise Google Maps URL.

Key Features:
-------------
* **No API Key Needed:** Uses OpenStreetMap and Leaflet (Free & Open Source).
* **Auto-Geolocation:** Automatically detects the user's current position (GPS) upon opening.
* **One-Click Selection:** Click anywhere on the map to pinpoint the location.
* **Google Maps Integration:** Saves the selected coordinates as a clickable Google Maps link (perfect for sharing via WhatsApp or saving in customer records).
* **Responsive Design:** Works perfectly inside Odoo's new UI (OWL Framework).
* **Zero Configuration:** Just install and use.

How to Use:
-----------
1. Add the widget to any Char field in your XML view:
   ``<field name="your_field_name" widget="dtc_map_widget"/>``
2. Click the "Select" button in the form.
3. Allow location access (optional) or pick a spot on the map.
4. The field will be populated with a Google Maps link.

Technical Details:
------------------
* Framework: Odoo OWL
* Library: Leaflet JS
    """,
    'version': '18.0',
    'category': 'Extra Tools',
    'author': 'Abdulhameed Ismail',
    'website': 'https://www.linkedin.com/in/abdulhameed-ismail/',
    'depends': ['base', 'web'],
    'data': [

    ],
    'assets': {
        'web.assets_backend': [
            'ai_map_widget/static/src/components/ai_map_widget.xml',
            'ai_map_widget/static/src/components/ai_map_widget.js',
        ],
    },
    'images': ['static/description/icon.png'],
    "license": "LGPL-3",
    'installable': True,
    'application': False,
    'auto_install': False,
}
