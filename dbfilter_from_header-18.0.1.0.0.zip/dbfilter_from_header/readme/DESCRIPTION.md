This addon lets you pass a dbfilter as a HTTP header.

This is interesting for setups where database names can't be mapped to
proxied host names.
