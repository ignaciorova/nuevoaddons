# -*- coding: utf-8 -*-
{
    'name': 'Payment Subsidy Collaborator',
    'version': '18.0.1.0.0',
    'category': 'eCommerce/Payment',
    'summary': 'Método de pago por subsidio para colaboradores en website',
    'description': """
        Módulo de pago para colaboradores identificados por lista de precios y empresa.
        - Método de pago visible en website solo para colaboradores autorizados.
        - Al validar el pago, se confirma automáticamente y se envía notificación.
        - Vista de administración en backend para gestionar y ver los pagos.
    """,
    'author': 'Custom',
    'website': '',
    'depends': [
        'payment',
        'website_sale',
        'account',
        'sale',
        'mail',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/payment_provider_data.xml',
        'views/payment_subsidy_views.xml',
        'views/payment_provider_form.xml',
        'views/res_partner_views.xml',
        'views/website_payment_templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'payment_subsidy_collaborator/static/src/js/payment_subsidy.js',
        ],
    },
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
