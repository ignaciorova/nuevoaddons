# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_subsidy_collaborator = fields.Boolean(
        string='Es Colaborador de Subsidio',
        compute='_compute_is_subsidy_collaborator',
        store=False,
        help='Indica si este cliente califica como colaborador de subsidio '
             'según las listas de precio y empresa configuradas en el proveedor de pago.',
    )

    @api.depends('property_product_pricelist', 'company_id')
    def _compute_is_subsidy_collaborator(self):
        providers = self.env['payment.provider'].sudo().search([
            ('code', '=', 'subsidy_collaborator'),
            ('state', 'in', ['enabled', 'test']),
        ])
        for partner in self:
            is_collab = False
            for provider in providers:
                if provider._is_collaborator(partner):
                    is_collab = True
                    break
            partner.is_subsidy_collaborator = is_collab
