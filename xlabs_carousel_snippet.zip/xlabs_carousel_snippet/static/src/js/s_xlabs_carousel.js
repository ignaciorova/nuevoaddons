/** @odoo-module **/
// ============================================================
// s_xlabs_carousel — Lógica de navegación (frontend)
// ============================================================

import publicWidget from '@web/legacy/js/public/public_widget';

publicWidget.registry.sXlabsCarousel = publicWidget.Widget.extend({
    selector: '.s_xlabs_carousel',
    disabledInEditableMode: false,

    start() {
        this._super(...arguments);
        this._currentIndex = 0;
        this._slides = this.el.querySelectorAll('.s_xlabs_slide');
        this._track = this.el.querySelector('.s_xlabs_carousel_track');
        this._dots = this.el.querySelectorAll('.s_xlabs_dot');
        this._btnPrev = this.el.querySelector('.s_xlabs_btn_prev');
        this._btnNext = this.el.querySelector('.s_xlabs_btn_next');

        this._updateState();

        this._btnPrev.addEventListener('click', () => this._navigate(-1));
        this._btnNext.addEventListener('click', () => this._navigate(1));

        this._dots.forEach((dot) => {
            dot.addEventListener('click', () => {
                const idx = parseInt(dot.dataset.index, 10);
                this._goTo(idx);
            });
        });
    },

    _navigate(direction) {
        const total = this._slides.length;
        this._currentIndex = (this._currentIndex + direction + total) % total;
        this._updateState();
    },

    _goTo(index) {
        this._currentIndex = index;
        this._updateState();
    },

    _updateState() {
        // Mueve el track
        this._track.style.transform = `translateX(-${this._currentIndex * 100}%)`;

        // Actualiza dots
        this._dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === this._currentIndex);
        });

        // Deshabilita flechas en los extremos (opcional: quitar para loop infinito)
        // this._btnPrev.disabled = this._currentIndex === 0;
        // this._btnNext.disabled = this._currentIndex === this._slides.length - 1;
    },
});

export default publicWidget.registry.sXlabsCarousel;
