/** @odoo-module **/
// ============================================================
// s_xlabs_marquee — Opciones del Website Builder
// El fondo se configura con el selector de color de sección
// nativo de Odoo (o_colored_level / o_cc1..o_cc5).
// Los textos son editables inline con doble clic.
// ============================================================

import options from '@web_editor/js/editor/snippets.options';

options.registry.SXlabsMarquee = options.Class.extend({
    // El builder detecta automáticamente:
    //   - o_colored_level  → panel de color de fondo
    //   - o_default_snippet_text → edición inline de texto
});
