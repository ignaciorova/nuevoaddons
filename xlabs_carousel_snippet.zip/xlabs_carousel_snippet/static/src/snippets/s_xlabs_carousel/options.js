/** @odoo-module **/
// ============================================================
// s_xlabs_carousel — Opciones del Website Builder (editor)
// ============================================================
// Registra el snippet como editable:
//   • Imágenes  → selector nativo de medios de Odoo
//   • Subtítulo → editable inline (texto)
//   • Título    → editable inline (texto)
// ============================================================

import options from '@web_editor/js/editor/snippets.options';

options.registry.SXlabsCarousel = options.Class.extend({
    // No se necesitan opciones extra en el panel lateral por ahora.
    // El builder detecta automáticamente:
    //   - Elementos <img>        → botón "Reemplazar imagen"
    //   - Elementos con texto    → edición inline al hacer doble clic
});
