# Payment Subsidy Collaborator — Odoo 18

Módulo de pago personalizado para colaboradores con subsidio en el website de Odoo.

---

## 🚀 Funcionalidades

- **Método de pago exclusivo** visible en el checkout del website solo para colaboradores autorizados.
- **Identificación por Lista de Precios y Empresa** del partner.
- **Confirmación automática**: al enviar el pago, la transacción se marca como `done` (no queda en pendiente).
- **Notificaciones**: envío de correo al cliente y al administrador al confirmar el pago.
- **Vista backend**: menú *Subsidio Colaboradores > Pagos de Subsidio* para gestionar y confirmar pagos manualmente.
- **Badge en cliente**: indicador visual en el formulario del partner si es colaborador de subsidio.

---

## 📦 Dependencias

```
payment
website_sale
account
sale
mail
```

---

## ⚙️ Configuración

### 1. Activar el proveedor de pago

- Ir a **Contabilidad > Configuración > Proveedores de Pago**
- Buscar **"Subsidio Colaborador"**
- Activarlo (modo Test o Producción)

### 2. Configurar restricciones

En la pestaña **"Configuración Subsidio"** del proveedor:

| Campo | Descripción |
|---|---|
| **Listas de Precio Permitidas** | Solo los clientes con estas listas verán el método de pago |
| **Empresas Permitidas** | Filtro adicional por empresa del cliente |
| **Plantilla de Notificación** | Plantilla de email para el cliente (opcional) |
| **Email de Administrador** | Email que recibe notificación al confirmar el pago |

### 3. Flujo en website

1. El cliente con lista de precios y empresa autorizadas llega al checkout.
2. Ve el método **"Subsidio Colaborador"** disponible.
3. Al confirmar, la transacción se procesa automáticamente como `done`.
4. Se envían correos al cliente y al administrador.

---

## 🔧 Gestión desde Backend

Menú: **Subsidio Colaboradores > Pagos de Subsidio**

- Lista de todos los pagos de subsidio con estado visual.
- Botón **"Confirmar"** para validar manualmente pagos pendientes.
- Vista de detalle con órdenes de venta relacionadas y chatter.

---

## 📂 Estructura del módulo

```
payment_subsidy_collaborator/
├── __manifest__.py
├── __init__.py
├── controllers/
│   ├── __init__.py
│   └── payment_subsidy.py
├── data/
│   └── payment_provider_data.xml
├── models/
│   ├── __init__.py
│   ├── payment_provider.py
│   ├── payment_transaction.py
│   └── res_partner.py
├── security/
│   └── ir.model.access.csv
├── static/src/js/
│   └── payment_subsidy.js
└── views/
    ├── payment_provider_form.xml
    ├── payment_subsidy_views.xml
    ├── res_partner_views.xml
    └── website_payment_templates.xml
```
