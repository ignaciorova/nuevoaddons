/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import publicWidget from "@web/legacy/js/public/public_widget";

/**
 * Widget for Subsidy Collaborator Payment Form on website checkout.
 * Handles the frontend display and submission of the subsidy payment.
 */
publicWidget.registry.SubsidyPaymentForm = publicWidget.Widget.extend({
    selector: '#o_payment_subsidy_form',
    events: {},

    /**
     * @override
     */
    start() {
        this._super(...arguments);
        this._initSubsidyForm();
        return Promise.resolve();
    },

    /**
     * Initialize subsidy form behaviors.
     * @private
     */
    _initSubsidyForm() {
        // Show info banner with collaborator details
        const form = this.el;
        if (form) {
            form.classList.add('subsidy-initialized');
            console.log('[SubsidyPayment] Formulario de subsidio inicializado.');
        }
    },
});

export default publicWidget.registry.SubsidyPaymentForm;
