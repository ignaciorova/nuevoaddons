# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('subsidy_collaborator', 'Subsidio Colaborador')],
        ondelete={'subsidy_collaborator': 'set default'},
    )

    # Pricelist restriction
    subsidy_pricelist_ids = fields.Many2many(
        'product.pricelist',
        'payment_provider_pricelist_rel',
        'provider_id',
        'pricelist_id',
        string='Listas de Precio Permitidas',
        help='Solo los clientes con estas listas de precio verán este método de pago.',
    )

    # Company restriction
    subsidy_company_ids = fields.Many2many(
        'res.company',
        'payment_provider_company_rel',
        'provider_id',
        'company_id',
        string='Empresas Permitidas',
        help='Solo los clientes de estas empresas verán este método de pago.',
    )

    # Notification email template
    subsidy_notification_template_id = fields.Many2one(
        'mail.template',
        string='Plantilla de Notificación',
        domain="[('model', '=', 'payment.transaction')]",
        help='Plantilla de correo que se enviará al confirmar el pago.',
    )

    # Admin notification email
    subsidy_admin_email = fields.Char(
        string='Email de Administrador',
        help='Email al que se notificará cuando se confirme un pago de subsidio.',
    )

    def _is_collaborator(self, partner):
        """
        Verifica si un partner es colaborador según lista de precios y empresa.
        """
        self.ensure_one()
        if not partner:
            return False

        # Check pricelist
        if self.subsidy_pricelist_ids:
            partner_pricelist = partner.property_product_pricelist
            if partner_pricelist not in self.subsidy_pricelist_ids:
                return False

        # Check company
        if self.subsidy_company_ids:
            partner_company = partner.company_id
            if partner_company not in self.subsidy_company_ids:
                return False

        return True

    @api.model
    def _get_compatible_providers(self, *args, partner_id=None, **kwargs):
        """
        Filtra los proveedores de pago: el método de subsidio solo
        se muestra a colaboradores válidos.
        """
        providers = super()._get_compatible_providers(
            *args, partner_id=partner_id, **kwargs
        )
        partner = self.env['res.partner'].browse(partner_id) if partner_id else None

        filtered = self.env['payment.provider']
        for provider in providers:
            if provider.code == 'subsidy_collaborator':
                if partner and provider._is_collaborator(partner):
                    filtered |= provider
            else:
                filtered |= provider

        return filtered
